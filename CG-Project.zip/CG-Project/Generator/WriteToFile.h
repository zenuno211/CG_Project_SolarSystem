#include <stdio.h>

int writeVertexToFile(float x, float y, float z, FILE * filename);

int writeTextureToFile(float x, float y, FILE * filename);

int writePointsSizeToFile(long unsigned int x,FILE * filename);