#define _USE_MATH_DEFINES
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include "WriteToFile.h"
//#include "Coordinates.h"

using namespace std;

int NrPatches;
unsigned int *patches;
int NrPtsControlo;
float* pontosControlo; 

class Coordinates{
    public:
        float coordX;
        float coordY;
        float coordZ;

        Coordinates(){
            coordX = 0;
            coordY = 0;
            coordZ = 0;
        }

        Coordinates(float x, float y, float z){
            coordX = x;
            coordY = y;
            coordZ = z;
        }

        float getX(){
            return coordX;
        }
        
        float getY(){
            return coordY;
        }

        float getZ(){
            return coordZ;
        }

};


class Textures{
    public:
        float tX;
        float tY;

        Textures(){
            tX = 0;
            tY = 0;
        }

        Textures(float x, float y){
            tX = x;
            tY = y;
        }

        float getX(){
            return tX;
        }
        
        float getY(){
            return tY;
        }
};



void plane(float dimensao, string filename){
    FILE * file = fopen(filename.c_str(), "w");
    if(file == NULL){
        dimensao = 1;
        printf("Não consigo abrir o ficheiro!!");
    }
    vector<Coordinates> points;

    float coord = dimensao/2;

    //primeiro triangulo, virado para cima
    points.push_back(Coordinates(coord, 0.0, coord));
    points.push_back(Coordinates(coord, 0.0, -coord));
    points.push_back(Coordinates(-coord, 0.0, coord));

    //segundo triangulo, virado para cima
    points.push_back(Coordinates(-coord, 0.0, -coord));
    points.push_back(Coordinates(-coord, 0.0, coord));
    points.push_back(Coordinates(coord, 0.0, -coord));

    writePointsSizeToFile(points.size(),file);
    for(int p = 0; p < points.size(); p++){
        writeVertexToFile(points[p].coordX, points[p].coordY, points[p].coordZ,file);
    }

    fclose(file);

}



void box(float largura, float comprimento, float altura, int nrDivisions, string filename){
    FILE * file = fopen(filename.c_str(), "w");

    vector<Coordinates> points;

    float x = largura/nrDivisions;
    float y = altura/nrDivisions;
    float z = comprimento/nrDivisions;

    for(int i = 0; i<nrDivisions; i++){
        for(int j = 0; j<nrDivisions; j++){

            //face frontalXXX
            points.push_back(Coordinates(x * i - largura / 2, y * j - altura / 2, comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2 + x, y * j - altura / 2, comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2, y * j - altura / 2 + y, comprimento / 2));

            points.push_back(Coordinates(x * i - largura / 2 + x, y * j - altura / 2, comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2 + x, y * j - altura / 2 + y, comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2, y * j - altura / 2 + y, comprimento / 2));

            //face trás
            points.push_back(Coordinates(x * i - largura / 2, y * j - altura / 2, -comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2, y * j - altura / 2 + y, -comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2 + x, y * j - altura / 2, -comprimento / 2));

            points.push_back(Coordinates(x * i - largura / 2 + x, y * j - altura / 2, -comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2, y * j - altura / 2 + y, -comprimento / 2));
            points.push_back(Coordinates(x * i - largura / 2 + x, y * j - altura / 2 + y, -comprimento / 2));

            //face de lateral 1
            points.push_back(Coordinates(largura / 2, y * i - altura / 2, z * j - comprimento / 2));
            points.push_back(Coordinates(largura / 2, y * i - altura / 2 + y, z * j - comprimento / 2));
            points.push_back(Coordinates(largura / 2, y * i - altura / 2, z * j - comprimento / 2 + z));

            points.push_back(Coordinates(largura / 2, y * i - altura / 2, z * j - comprimento / 2 + z));
            points.push_back(Coordinates(largura / 2, y * i - altura / 2 + y, z * j - comprimento / 2));
            points.push_back(Coordinates(largura / 2, y * i - altura / 2 + y, z * j - comprimento / 2 + z));

            //face de lateral 2
            points.push_back(Coordinates(-largura / 2, y * i - altura / 2, z * j - comprimento / 2));
            points.push_back(Coordinates(-largura / 2, y * i - altura / 2, z * j - comprimento / 2 + z));
            points.push_back(Coordinates(-largura / 2, y * i - altura / 2 + y, z * j - comprimento / 2));


            points.push_back(Coordinates(-largura / 2, y * i - altura / 2, z * j - comprimento / 2 + z));
            points.push_back(Coordinates(-largura / 2, y * i - altura / 2 + y, z * j - comprimento / 2 + z));
            points.push_back(Coordinates(-largura / 2, y * i - altura / 2 + y, z * j - comprimento / 2));

            //face de cima
            points.push_back(Coordinates(x * j - largura / 2, altura / 2, z * i - comprimento / 2));
            points.push_back(Coordinates(x * j - largura / 2, altura / 2, z * i - comprimento / 2 + z));
            points.push_back(Coordinates(x * j - largura / 2 + x, altura / 2, z * i - comprimento / 2));

            points.push_back(Coordinates(x * j - largura / 2, altura / 2, z * i - comprimento / 2 + z));
            points.push_back(Coordinates(x * j - largura / 2 + x, altura / 2, z * i - comprimento / 2 + z));
            points.push_back(Coordinates(x * j - largura / 2 + x, altura / 2, z * i - comprimento / 2));

            //face de baixo
            points.push_back(Coordinates(x * j - largura / 2, -altura / 2, z * i - comprimento / 2));
            points.push_back(Coordinates(x * j - largura / 2 + x, -altura / 2, z * i - comprimento / 2));
            points.push_back(Coordinates(x * j - largura / 2, -altura / 2, z * i - comprimento / 2 + z));

            points.push_back(Coordinates(x * j - largura / 2, -altura / 2, z * i - comprimento / 2 + z));
            points.push_back(Coordinates(x * j - largura / 2 + x, -altura / 2, z * i - comprimento / 2));
            points.push_back(Coordinates(x * j - largura / 2 + x, -altura / 2, z * i - comprimento / 2 + z));

        }
    }

    writePointsSizeToFile(points.size(),file);
    for(int p = 0; p < points.size(); p++){
        writeVertexToFile(points[p].coordX, points[p].coordY, points[p].coordZ,file);
    }

    fclose(file);

}

Coordinates pointsSphere (float radius, float beta, float alpha){
    Coordinates result;
    
    result.coordX = radius * sin(alpha) * cos(beta);
    result.coordY = radius * sin(beta);
    result.coordZ = radius * cos(beta) * cos(alpha);
    
    return result;
}

void sphere(float radius, int slices, int stacks, string filename){
    FILE * file = fopen(filename.c_str(), "w");
    
    Coordinates p1, p2, p3, p4;
    vector<Coordinates> points;
    vector<Coordinates> normals;
    vector<Textures> texts;
    float alpha, nextAlpha,
    beta, nextBeta;
    
    for (int i = 0; i < stacks; i++)
    {
        beta = i * (M_PI / stacks) - M_PI_2;
        nextBeta = (i + 1) * (M_PI / stacks) - M_PI_2;
        
        for (int j = 0; j < slices; j++)
        {
            alpha = j * 2 * M_PI / slices;
            nextAlpha = (j + 1) * 2 * M_PI / slices;
            
            p1 = pointsSphere(radius, nextBeta, alpha);
            p2 = pointsSphere(radius, beta, alpha);
            p3 = pointsSphere(radius, nextBeta, nextAlpha);
            p4 = pointsSphere(radius, beta, nextAlpha);

            // First triangle
            points.push_back(p1);
            points.push_back(p2);
            points.push_back(p3);

            // Second triangle
            points.push_back(p3);
            points.push_back(p2);
            points.push_back(p4);

            p1 = pointsSphere(1,nextBeta,alpha);
            p2 = pointsSphere(1,beta,alpha);
            p3 = pointsSphere(1,nextBeta,nextAlpha);
            p4 = pointsSphere(1,beta,nextAlpha);

            //normal
			normals.push_back(p1);
			normals.push_back(p2);
		    normals.push_back(p3);
			normals.push_back(p3);
			normals.push_back(p2);
			normals.push_back(p4);

            //texture
			texts.push_back( Textures(j/slices ,(i+1)/stacks));
			texts.push_back( Textures(j/slices, i/stacks));
			texts.push_back( Textures((j+1)/slices,(i+1)/stacks));
			texts.push_back( Textures((j+1)/slices,(i+1)/stacks));
			texts.push_back( Textures(j/slices, i/stacks));
			texts.push_back( Textures((j+1)/slices, i/stacks));
        }
    }

    writePointsSizeToFile(points.size(),file);
    for(int p = 0; p < points.size(); p++){
        writeVertexToFile(points[p].coordX, points[p].coordY, points[p].coordZ,file);
    }
    for(int n = 0; n < normals.size(); n++){
        writeVertexToFile(normals[n].coordX, normals[n].coordY, normals[n].coordZ,file);
    }
    for(int n = 0; n < texts.size(); n++){
        writeTextureToFile(texts[n].tX, texts[n].tY,file);
    }

    fclose(file);
}


void cone(float raio, float altura, int slices, int stacks, string filename){
    // cone(raio, altura, slices, stacks, filename)
    FILE * file = fopen(filename.c_str(), "w");

    vector<Coordinates> points;

    //Vertices
    float a = 0; //alpha
    float a_shift = (2 * M_PI) / slices; //desl. angular aka proximo vertice
    float r_shift = raio / stacks;
    float h_init = -altura / 2;
    float h_shift = altura / stacks; // desl. vertical (ao longo do eixo Y)

    for (a = 0; a < 2 * M_PI; a += a_shift) {

      //base do cone
      points.push_back(Coordinates(raio * sin(a), h_init, (raio * cos(a))));
      points.push_back(Coordinates(0, h_init, 0)); //origem no centro do cone
      points.push_back(Coordinates(raio * sin(a + a_shift), h_init,raio * cos(a + a_shift)));
    }

    //laterias
    for (int i = 0; i < stacks; i++) {
        for (int j = 0; j < slices; j++) {
            a += a_shift;
            float new_r = raio - r_shift;

            points.push_back(Coordinates(raio * sin(a), h_init,raio * cos(a)));
            points.push_back(Coordinates(raio * sin(a + a_shift), h_init, raio * cos(a + a_shift)));
            points.push_back(Coordinates(new_r * sin(a), (h_init + h_shift),new_r * cos(a)));

            points.push_back(Coordinates(raio * sin(a + a_shift), h_init, raio * cos(a + a_shift)));
            points.push_back(Coordinates(new_r * sin(a + a_shift), (h_init + h_shift), new_r * cos(a + a_shift)));
            points.push_back(Coordinates(new_r * sin(a), (h_init + h_shift), new_r * cos(a))); 
        }

        raio -= r_shift;
        h_init += h_shift;
    }

    writePointsSizeToFile(points.size(),file);
    for(int p = 0; p < points.size(); p++){
        writeVertexToFile(points[p].coordX, points[p].coordY, points[p].coordZ,file);
    } 
    fclose(file);
}

void  cilindro(float raio, float altura, float slices, string filename) {

    FILE* file = fopen(filename.c_str(), "w");
    vector<Coordinates> points;

    //Vertices
    float desl = (2 * M_PI) / slices;
    float y = altura / 2;
    float angle = 0;
 

    for (int i = 0; i < slices; i++) {
        angle = desl * i;

        //Circulo de cima
      
        points.push_back(Coordinates(raio * sin(angle + desl), y, raio * cos(angle + desl)));
        points.push_back(Coordinates(0, y, 0));
        points.push_back(Coordinates(raio * sin(angle), y, raio * cos(angle)));

        //Circulo de baixo
    
        points.push_back(Coordinates(raio * sin(angle), -y, raio * cos(angle)));
        points.push_back(Coordinates(0, -y, 0));
        points.push_back(Coordinates(raio * sin(angle + desl), -y, raio * cos(angle + desl)));
      
        //laterais 

        points.push_back(Coordinates(raio * sin(angle), -y, raio * cos(angle)));
        points.push_back(Coordinates(raio * sin(angle + desl), -y, raio * cos(angle + desl)));
        points.push_back(Coordinates(raio * sin(angle + desl), y, raio * cos(angle + desl)));

        points.push_back(Coordinates(raio * sin(angle + desl), y, raio * cos(angle + desl)));
        points.push_back(Coordinates(raio * sin(angle), y, raio * cos(angle)));
        points.push_back(Coordinates(raio * sin(angle), -y, raio * cos(angle)));


        }

    writePointsSizeToFile(points.size(),file);
    for(int p = 0; p < points.size(); p++){
        writeVertexToFile(points[p].coordX, points[p].coordY, points[p].coordZ,file);
    }
    
    fclose(file);

}


Coordinates pointsTorus(float radiusIn,float radiusOut,float beta,float alpha){

    Coordinates result;

    result.coordX = cos(alpha) * (radiusIn*cos(beta) + radiusOut);
    result.coordY = sin(alpha) * (radiusIn*cos(beta) + radiusOut);
    result.coordZ = radiusIn  * sin(beta);

    return result;
}

void torus(float radiusIn, float radiusOut, int slices, int stacks, string filename){
    FILE* file = fopen(filename.c_str(), "w");

    Coordinates p1,p2,p3,p4;
    vector<Coordinates> points;
    vector<Coordinates> normals;
    vector<Textures> texts;
    
    for (int i = 0; i < stacks; i++)
    {
        float beta =  i * (2*M_PI)/stacks;
        float nextBeta =  (i+1) * (2*M_PI)/stacks;
        
        for (int j = 0; j < slices; j++)
        {
            float alpha = j * (2*M_PI)/slices;
            float nextAlpha = (j+1) * (2*M_PI)/slices;
            
            p1 = pointsTorus(radiusIn,radiusOut,beta,alpha);
            p2 = pointsTorus(radiusIn,radiusOut,beta,nextAlpha);
            p3 = pointsTorus(radiusIn,radiusOut,nextBeta,alpha);
            p4 = pointsTorus(radiusIn,radiusOut,nextBeta,nextAlpha);
            
            points.push_back(p1);
            points.push_back(p2);
            points.push_back(p3);
            
            points.push_back(p3);
            points.push_back(p2);
            points.push_back(p4);
            
            p1 = pointsTorus(1,1,beta,alpha);
            p2 = pointsTorus(1,1,beta,nextAlpha);
            p3 = pointsTorus(1,1,nextBeta,alpha);
            p4 = pointsTorus(1,1,nextBeta,nextAlpha);
            
			normals.push_back(p1);
            normals.push_back(p2);
            normals.push_back(p3);
			normals.push_back(p3);
            normals.push_back(p2);
            normals.push_back(p4);

			texts.push_back( Textures((float) j/slices, (float) i/stacks));
			texts.push_back( Textures((float)(j+1)/slices, (float) i/stacks));
			texts.push_back( Textures((float) j/slices, (float) (i+1)/stacks));
			texts.push_back( Textures((float) j/slices, (float)(i+1)/stacks));
			texts.push_back( Textures((float)(j+1)/slices, (float) i/stacks));
			texts.push_back( Textures((float)(j+1)/slices, (float)(i+1)/stacks));
        }
    }

    writePointsSizeToFile(points.size(),file);
    for(int p = 0; p < points.size(); p++){
        writeVertexToFile(points[p].coordX, points[p].coordY, points[p].coordZ,file);
    }
    for(int n = 0; n < normals.size(); n++){
        writeVertexToFile(normals[n].coordX, normals[n].coordY, normals[n].coordZ,file);
    }
    for(int n = 0; n < texts.size(); n++){
        writeTextureToFile(texts[n].tX, texts[n].tY,file);
    }

    fclose(file);
}
    
void parseBezier(string filename){

    ifstream file;
    file.open(filename.c_str());
    string fslinha,linha;

    //inserir valor dos indices dos patches no array(patches)
    getline(file,fslinha); //coloca no fsline 
    NrPatches = atoi(fslinha.c_str());
    patches = (unsigned int*) malloc(sizeof(unsigned int)*NrPatches*16);
    
    for(int i = 0; i < NrPatches; i++){
        getline(file,linha);
        istringstream indices(linha);
        string index;
        for(int j = 0; j < 16 && getline(indices,index,',');j++){
            patches[i*16+j] = atoi(index.c_str());
        }
    }
    
    //inserir os pontos de controlo no array(Pontos Controlo)
    getline(file,fslinha);
    NrPtsControlo = atoi(fslinha.c_str());
    pontosControlo = (float*) malloc(sizeof(float)*3*NrPtsControlo);
    
    for (int ptC = 0; ptC < NrPtsControlo; ptC++){
        getline(file,linha);
        istringstream indices(linha);
        string index;
        for(int j = 0; j < 3 && getline(indices,index, ','); j++ ){
            pontosControlo[ptC*3+j] = atof(index.c_str());
        }
    }
}

Coordinates* pontoDeBezier(int patch, float u, float v){
    Coordinates* coord = new Coordinates();

    //Polinómios de Bernstein
    //(1-t)^3 * P0 + 3t(1-t)^2 * P1 + 3t^2(1-t) * P2 + t^3 * P3
    float bu[4] = {(powf(1-u,3)),(3*u*powf(1-u,2)), (3*powf(u,2)*(1-u)),(powf(u,3))};
    float bv[4] = {(powf(1-v,3)),(3*v*powf(1-v,2)), (3*powf(v,2)*(1-v)),(powf(v,3))};

    for(int j=0; j<4; j++){
        for(int i=0; i<4;i++){

            //Indice dentro de um patch
            int indexP = j*4+i;
            //Respetivo indice do pento de controlo
            int indexPC = patches[patch*16+indexP];


            float x = coord->coordX + pontosControlo[indexPC*3] * bu[j] * bv[i];
            float y = coord->coordY + pontosControlo[indexPC*3+1] * bu[j] * bv[i];
            float z = coord->coordZ + pontosControlo[indexPC*3+2] * bu[j] * bv[i];

            coord = new Coordinates(x,y,z);
            
        }
    }

    return coord;
}

Coordinates* pontoDeBezierNormal(int patch, float u, float v){
    Coordinates* coord = new Coordinates();

    for(int j=0; j<4; j++){
        for(int i=0; i<4;i++){

            //Indice dentro de um patch
            int indexP = j*4+i;
            //Respetivo indice do pento de controlo
            int indexPC = patches[patch*16+indexP];


            float x = coord->coordX + pontosControlo[indexPC*3];
            float y = coord->coordY + pontosControlo[indexPC*3+1];
            float z = coord->coordZ + pontosControlo[indexPC*3+2];

            coord = new Coordinates(x,y,z);
            
        }
    }

    return coord;
}



void bezier(string patchfile, int tesselation, string file3d){
    parseBezier(patchfile);
    
    FILE* fileTowrite = fopen(file3d.c_str(), "w");

    vector<Coordinates> points;
    vector<Coordinates> normals;
    vector<Textures> text; 

    for(int patch=0; patch<NrPatches; patch++){
        for(int tessv=0; tessv<tesselation;tessv++){
            float v = (float) tessv/tesselation;

            for(int tessu=0; tessu<tesselation;tessu++){
                float u = (float) tessu/tesselation;
                
                //triangulo super
                Coordinates* p1 = pontoDeBezier(patch,u+(1.0f/tesselation),v+(1.0f/tesselation));
                Coordinates* p2 = pontoDeBezier(patch,u,v);
                Coordinates* p3 = pontoDeBezier(patch,u,v+(1.0f/tesselation));

                //triangulo inf
                Coordinates* p4 = pontoDeBezier(patch,u+(1.0f/tesselation),v+(1.0f/tesselation));
                Coordinates* p5 = pontoDeBezier(patch,u+(1.0f/tesselation),v);
                Coordinates* p6 = pontoDeBezier(patch,u,v);
                
                points.push_back(Coordinates(p1->coordX,p1->coordY,p1->coordZ));
                points.push_back(Coordinates(p2->coordX,p2->coordY,p2->coordZ));
                points.push_back(Coordinates(p3->coordX,p3->coordY,p3->coordZ));
                
                points.push_back(Coordinates(p4->coordX,p4->coordY,p4->coordZ));
                points.push_back(Coordinates(p5->coordX,p5->coordY,p5->coordZ));
                points.push_back(Coordinates(p6->coordX,p6->coordY,p6->coordZ));

                 //triangulo super
                Coordinates* n1 = pontoDeBezierNormal(patch,u+(1.0f/tesselation),v+(1.0f/tesselation));
                Coordinates* n2 = pontoDeBezierNormal(patch,u,v);
                Coordinates* n3 = pontoDeBezierNormal(patch,u+(1.0f/tesselation),v);

                //triangulo inf
                Coordinates* n4 = pontoDeBezierNormal(patch,u+(1.0f/tesselation),v+(1.0f/tesselation));
                Coordinates* n5 = pontoDeBezierNormal(patch,u,v+(1.0f/tesselation));
                Coordinates* n6 = pontoDeBezierNormal(patch,u,v);
                
                normals.push_back(Coordinates(n1->coordX,n1->coordY,n1->coordZ));
                normals.push_back(Coordinates(n2->coordX,n2->coordY,n2->coordZ));
                normals.push_back(Coordinates(n3->coordX,n3->coordY,n3->coordZ));
                
                normals.push_back(Coordinates(n4->coordX,n4->coordY,n4->coordZ));
                normals.push_back(Coordinates(n5->coordX,n5->coordY,n5->coordZ));
                normals.push_back(Coordinates(n6->coordX,n6->coordY,n6->coordZ));

                //triangulo super
                text.push_back(Textures(u+(1.0f/tesselation),v+(1.0f/tesselation)));
                text.push_back(Textures(u,v));
                text.push_back(Textures(u,v+(1.0f/tesselation)));

                //triangulo inf
                text.push_back(Textures(u+(1.0f/tesselation),v+(1.0f/tesselation)));
                text.push_back(Textures(u+(1.0f/tesselation),v));
                text.push_back(Textures(u,v));      

            }
        }
    }

    writePointsSizeToFile(points.size(),fileTowrite);
    for(int p = 0; p < points.size(); p++){
        writeVertexToFile(points[p].coordX, points[p].coordY, points[p].coordZ,fileTowrite);
    }

    for(int n = 0; n < normals.size(); n++){
        writeVertexToFile(normals[n].coordX, normals[n].coordY, normals[n].coordZ,fileTowrite);
    }

    for(int t = 0; t < text.size(); t++){
        writeTextureToFile(text[t].tX, text[t].tY,fileTowrite);
    }
    
    fclose(fileTowrite);
    free(patches);
    free(pontosControlo);
}



int main(int argc, char* argv[]) {


    if (argc < 2) {
        printf("Parametros Inválidos.\nA sair da aplicação...");
        return -1;
    }


    string figura = argv[1]; //plane,box,sphere,cone,cilindro
    string generated_path = "../Ficheiros3D/";
    string generated_path_Bezier = "../Patches/";

    if (figura == "-help"){
        printf("----Menu de Ajuda----\n");
        printf("> ./generator plane <dimensao> <ficheiro>\n");
        printf("> ./generator box <largura> <comprimento> <altura> <NrDivisões> <ficheiro>\n");
        printf("> ./generator sphere <raio> <slices> <stacks> <ficheiro>\n");
        printf("> ./generator cone <raio> <altura> <slices> <stacks> <ficheiro>\n");
        printf("> ./generator cilinder <raio> <altura> <slices> <ficheiro>\n");
        printf("> ./generator torus <outterRadius> <innerRadius> <slices> <rings> <ficheiro>\n");
        printf("> ./generator comet <ficheiro patch> <tesselação> <ficheiro>\n");
        return 0;
    }

    if (figura == "plane") {
        float dimensao = std::stof(argv[2]); //(stof)convert string to float
        string filename = argv[3];
        filename = generated_path + filename;

        plane(dimensao, filename);

        return 0;
    }


    else if (figura=="box"){

        float largura=std::stof(argv[2]);
        float comprimento=std::stof(argv[3]);
        float altura=std::stof(argv[4]);
        int nrDivisions=std::stoi(argv[5]); //(stoi) convert string to int

        string filename = argv[6];
        filename = generated_path + filename;
        box(largura,comprimento,altura, nrDivisions,filename);

        return 0;
    }


    else if (figura=="sphere"){

        float raio=std::stof(argv[2]);
        int slices=std::stoi(argv[3]);
        int stacks=std::stoi(argv[4]);

        string filename = argv[5];
        filename = generated_path + filename;
        sphere(raio, slices , stacks, filename);

        return 0;
    }
    else if (figura=="cone") {

        float raio = std::stof(argv[2]);
        float altura = std::stof(argv[3]);
        int slices = std::stoi(argv[4]);
        int stacks = std::stoi(argv[5]);

        string filename = argv[6];
        filename = generated_path + filename;
        cone(raio, altura, slices, stacks, filename);

        return 0;
    }
    else if (figura == "cilinder") {

        float raio = std::stof(argv[2]);
        float altura = std::stof(argv[3]);
        int slices = std::stof(argv[4]);

        string filename = argv[5];
        filename = generated_path + filename;
        cilindro(raio, altura, slices, filename);
        return 0;
    }
    else if (figura == "torus") {

        float outterRadius = std::stof(argv[2]);
        float innerRadius = std::stof(argv[3]);
        int slices = std::stoi(argv[4]);
        int rings = std::stoi(argv[5]);

        string filename = argv[6];
        filename = generated_path + filename;
        torus(innerRadius,outterRadius, slices, rings, filename);
        return 0;
    }

    else if (figura == "comet"){

        string fileToRead = argv[2];
        int tesselation = std::stoi(argv[3]);
        string fileToWrite = argv[4];
        
        fileToRead = generated_path_Bezier + fileToRead;
        fileToWrite = generated_path + fileToWrite;
        
        bezier(fileToRead,tesselation,fileToWrite);
        return 0;
    }

    // Se chegar aqui significa que os parâmetros são inválidos
    printf("Parametros Inválidos.\nA sair da aplicação...\n");
    return -1;
}
