#include "WriteToFile.h"
#include <stdio.h>

using namespace std;

int writeVertexToFile(float x, float y, float z, FILE * filename){
    if(filename == NULL){
        printf("Erro a abrir ficheiro!");
        return 1;
    }
    fprintf(filename, "%f %f %f\n",x,y,z);
}

int writeTextureToFile(float x, float y, FILE * filename){
    if(filename == NULL){
        printf("Erro a abrir ficheiro!");
        return 1;
    }
    fprintf(filename, "%f %f\n",x,y);
}

int writePointsSizeToFile(long unsigned int x,FILE * filename){
    if(filename == NULL){
        printf("Erro a abrir ficheiro!");
        return 1;
    }
    fprintf(filename, "%lu\n",x);
}

