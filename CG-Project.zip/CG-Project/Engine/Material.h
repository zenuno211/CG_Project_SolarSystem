#ifndef MATERIAL_H
#define MATERIAL_H
#include <math.h>

class Material{

public: 
    float *diffuse;
    float *specular;
    float *emissive;
    float *ambient;
    Material();
}; 

#endif