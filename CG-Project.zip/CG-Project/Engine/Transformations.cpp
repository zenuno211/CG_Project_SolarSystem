#include "Transformations.h"

Transformations::Transformations(){}

Transformations::Transformations(Translation* t, Rotation* r, Scale* s, Color* c){
    translation = t;
    rotation = r;
    scale = s;
    color = c;
}

void Transformations::setTranslation(Translation* t){
    translation = t;

}

void Transformations::setRotation(Rotation* r){
    rotation = r;
}

void Transformations::setScale(Scale* s){
    scale = s;
}

void Transformations::setColor(Color* c){
    color = c;
}

Translation* Transformations::getTranslation(){
    return translation;
}   

Rotation* Transformations::getRotation(){
    return rotation;
}

Scale* Transformations::getScale(){
    return scale;
}

Color* Transformations::getColor(){
    return color;
}

