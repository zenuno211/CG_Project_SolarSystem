#include "Group.h"

Group::Group(){}

Group::Group(std::vector<Transformations*> t, std::vector<Group*> n){
	transformations = t;
	next = n;
}

void Group::setTransformations(std::vector<Transformations*> t){
	transformations = t;
}

/* void Group::setFiguras(std::vector<Figura*> f){
	figuras=f;
} */

void Group::setFigure(Figura* figura){
	figure = figura;
}

void Group::setNext(std::vector<Group*> n){
	next = n;
}
	
std::vector<Transformations*> Group::getTransformations(){
	return transformations;
}

/*
std::vector<Figura*> Group::getFiguras(){
	return figuras;
}*/

Figura* Group::getFigure(){
	return figure;
}

std::vector<Group*> Group::getNext(){
	return next;
}

/* void Group::InsereFigura(Figura* f){
	figuras.push_back(f);
} */

void Group::InsereTransformations(Transformations* t){
	transformations.push_back(t);
}

void Group::InsereGroup(Group* g){
    next.push_back(g);
}

void Group::InsereTextura(std::string text){
	textura = text;
}
	
std::string Group::getTextura(){
	return textura;
}
