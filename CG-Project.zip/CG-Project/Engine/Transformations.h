
#include "Translation.h"
#include "Rotation.h"
#include "Scale.h"
#include "Color.h"


#ifndef Transformations_H
#define Transformations_H

class Transformations{
    Translation* translation;
    Rotation* rotation;
    Scale* scale;
    Color* color;
    
    public :
        Transformations();
        Transformations(Translation* t, Rotation* r, Scale* s, Color* c);
        void setTranslation(Translation* t);
        void setRotation(Rotation* r);
        void setScale(Scale* s);
        void setColor(Color* c);
        Translation* getTranslation();
        Rotation* getRotation();
        Scale* getScale();
        Color* getColor();
};

#endif