#ifndef COORDINATES_H
#define COORDINATES_H

class Coordinates{
    public:
        float coordX;
        float coordY;
        float coordZ;
        
        Coordinates();
        Coordinates(float xx, float yy, float zz);
        void setX(float x);
        void setY(float y);
        void setZ(float z);
        float getX();
        float getY();
        float getZ();
};

#endif 