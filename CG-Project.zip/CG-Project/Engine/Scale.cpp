#include "Scale.h"

Scale::Scale(){
    x = 1;
    y = 1;
    z = 1;
}

Scale::Scale(float xx, float yy, float zz) {
    x = xx;
    y = yy;
    z = zz;
};


float Scale::getX(){
    return x; 
}

float Scale::getY(){
    return y;
}

float Scale::getZ(){
    return z;
}
