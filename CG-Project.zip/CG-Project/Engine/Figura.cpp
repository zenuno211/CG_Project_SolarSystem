//#include <GL/glew.h>
//#include <GL/glut.h>
#include "Figura.h"

Figura::Figura(){}

Figura::Figura(std::vector<Coordinates*> f){
    figura = f;
}

std::vector<Coordinates*> Figura::getFigura(){
    return figura;
}

std::vector<Coordinates*> Figura::getNormals(){
    return normals;
}

std::vector<Textures*> Figura::getTextures(){
    return textures;
}

void Figura::InsereCoordenada(Coordinates* coord){
    figura.push_back(coord);
}

void Figura::InsereNormal(Coordinates* norm){
    normals.push_back(norm);
}

void Figura::InsereTextura(Textures* text){
    textures.push_back(text);
}

void Figura::setMaterial(Material* mat){
    material = mat;
}

Material* Figura::getMaterial(){
    return material;
}

int Figura::countVertix(){
    std::vector<Coordinates*>::iterator it; //apontador para apontador de coordenadas
        int nrvertices = 0;
        
    for(it = figura.begin(); it != figura.end(); it++) { 
        nrvertices+=3;  
    }
    return nrvertices;
}

int Figura::countNormals(){
    std::vector<Coordinates*>::iterator it; //apontador para apontador de coordenadas
        int nrNormals = 0;
        
    for(it = normals.begin(); it != normals.end(); it++) { 
        nrNormals+=3;  
    }
    return nrNormals;
}


int Figura::countTextures(){
    std::vector<Textures*>::iterator it; //apontador para apontador de coordenadas
        int nrTextures = 0;
        
    for(it = textures.begin(); it != textures.end(); it++) { 
        nrTextures+=2;  
    }
    return nrTextures;
}

void Figura::setTexture(GLuint t){
    texture = t;
}

GLuint Figura::getTextureID(){
    return texture;
}