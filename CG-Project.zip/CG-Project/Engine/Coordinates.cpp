#include "Coordinates.h"

Coordinates::Coordinates(){}

Coordinates::Coordinates(float x, float y, float z){
    coordX=x;
    coordY=y;
    coordZ=z;
}

void Coordinates::setX(float x){
    coordX=x; 
}

void Coordinates::setY(float y){
    coordY=y;
}

void Coordinates::setZ(float z){
    coordZ=z;
}

float Coordinates::getX(){
    return coordX; 
}

float Coordinates::getY(){
    return coordY;
}

float Coordinates::getZ(){
    return coordZ;
}


