#include <iostream>
#include <vector>

#include "Transformations.h"
#include "Figura.h"

#ifndef GROUP_H
#define GROUP_H


class Group {
	std::vector<Transformations*> transformations;
	std::vector<Group*> next;
	//std::vector<Figura*> figuras;
	Figura* figure; //new
	std::string textura;
	
public:
	Group();
	Group(std::vector<Transformations*> t, std::vector<Group*> n);
	void setTransformations(std::vector<Transformations*> t);
	//void setFiguras(std::vector<Figura*>f);
	void setFigure(Figura* figura); //new
	void setNext(std::vector<Group*> n);
	std::vector<Transformations*> getTransformations();
	//std::vector<Figura*> getFiguras();
	Figura* getFigure(); //new
	std::vector<Group*> getNext();
	//void InsereFigura(Figura* f);
	void InsereTransformations(Transformations* t);
	void InsereGroup(Group* g);
	void InsereTextura(std::string text);
	std::string getTextura();
};

#endif 