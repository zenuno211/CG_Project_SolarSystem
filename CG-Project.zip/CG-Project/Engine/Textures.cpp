#include "Textures.h"

Textures::Textures(){}

Textures::Textures(float x, float y){
    coordX=x;
    coordY=y;
}

void Textures::setX(float x){
    coordX=x; 
}

void Textures::setY(float y){
    coordY=y;
}

float Textures::getX(){
    return coordX; 
}

float Textures::getY(){
    return coordY;
}
