#ifndef TEXTURES_H
#define TEXTURES_H

class Textures{
    public:
        float coordX;
        float coordY;
        
        Textures();
        Textures(float xx, float yy);
        void setX(float x);
        void setY(float y);
        float getX();
        float getY();
};

#endif