#ifndef COLOR_H
#define COLOR_H

class Color{
     float red;
     float green;
     float blue;

public:
    Color();
    Color(float red, float green, float blue);
    float getRed();
    float getGreen();
    float getBlue();
 };

 #endif 