#ifndef Scale_H
#define Scale_H


class Scale{
    float x;
    float y;
    float z;

    public:
        Scale();
        Scale(float xx, float yy, float zz);
        float getX();
        float getY();
        float getZ();

};

#endif