#include "Coordinates.h"
#include "Textures.h"
#include "Material.h"
#include <iostream>
#include <vector>
#include <GL/glew.h>
#include <GL/glut.h>

#ifndef FIGURA_H
#define FIGURA_H

class Figura {
    std::vector<Coordinates*> figura;
    std::vector<Coordinates*> normals;
    std::vector<Textures*> textures;
    Material* material;
    GLuint texture;

public:
    Figura();
    Figura(std::vector<Coordinates*> f);
    std::vector<Coordinates*> getFigura();
    std::vector<Coordinates*> getNormals();
    std::vector<Textures*> getTextures();
    void InsereCoordenada(Coordinates* coord);
    void InsereNormal(Coordinates* norm);
    void InsereTextura(Textures* text);
    int countVertix();
    int countNormals();
    int countTextures();
    void setMaterial(Material* mat);
    Material* getMaterial();
    void setTexture(GLuint t);
    GLuint getTextureID();
};

#endif