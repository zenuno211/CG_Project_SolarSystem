#include "Rotation.h"

Rotation::Rotation(){
    angle = 0;
    time = 0;
    x = 0;
    y = 0;
    z = 0;
}


Rotation::Rotation(float angleR, float t , float xx, float yy, float zz){
    angle = angleR;
    time = t;
    x = xx;
    y = yy;
    z = zz;    
}

float Rotation::getAngle(){
    return angle;
}

float Rotation::getX(){
    return x; 
}

float Rotation::getY(){
    return y;
}

float Rotation::getZ(){
    return z;
}

float Rotation::getTime(){
    return time;
}


