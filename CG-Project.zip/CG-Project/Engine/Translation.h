#include <iostream>
#include <vector>
#include <math.h>

#include "Coordinates.h"

#ifndef TRANSLATION_H
#define TRANSLATION_H


class Translation{
    float time;
    std::vector<Coordinates*> points;
    float x;
    float y;
    float z;

    public:
        Translation();
        Translation(float t, std::vector<Coordinates*> ps, float xx, float yy, float zz);
        float getX();
        float getY();
        float getZ();
        float getTime();
        std::vector<Coordinates*> getPoints();
        void getCatmullRomPoint(float t, int* indices, float *pos, std::vector<Coordinates*> vertix);
        void getGlobalCatmullRomPoint(float gt, float *pos, std::vector<Coordinates*> vertixs);
        std::vector<Coordinates*> catmullCurve(); 
};

#endif