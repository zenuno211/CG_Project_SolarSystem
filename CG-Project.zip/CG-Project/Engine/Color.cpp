#include "Color.h"

Color::Color(){
    red = 1;
    green = 1;
    blue = 1;
}

Color::Color(float red2, float green2, float blue2){
    red = red2;
    green = green2;
    blue = blue2;
}

float Color::getRed(){
    return red;
}

float Color::getGreen(){
    return green;
}

float Color::getBlue(){
    return blue;
}