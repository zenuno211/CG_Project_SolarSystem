#include "Translation.h"

Translation::Translation(){  //Não sei até que ponto não precisa de inicializar nada!
    time = 0;
    x = 0;
    y = 0;
    z = 0;
}

Translation::Translation(float t, std::vector<Coordinates*> ps, float xx, float yy, float zz){
    time = t;
    points = ps;
    x = xx;
    y = yy;
    z = zz;
}

float Translation::getX(){
    return x; 
}

float Translation::getY(){
    return y;
}

float Translation::getZ(){
    return z;
}

float Translation::getTime(){
    return time;
}

std::vector<Coordinates*> Translation::getPoints(){
    return points;
}


void Translation::getCatmullRomPoint(float t, int* indices, float *pos, std::vector<Coordinates*> vertix){
     
     // catmull-rom matrix
	float m[4][4] = {	{-0.5f,  1.5f, -1.5f,  0.5f},
						{ 1.0f, -2.5f,  2.0f, -0.5f},
						{-0.5f,  0.0f,  0.5f,  0.0f},
						{ 0.0f,  1.0f,  0.0f,  0.0f} };
    pos[0] = 0;
    pos[1] = 0;
    pos[2] = 0;

    float matrixA[4];

    //T*M
    matrixA[0]=(t*t*t*m[0][0])+(t*t*m[1][0])+(t*m[2][0])+(m[3][0]);
    matrixA[1]=(t*t*t*m[0][1])+(t*t*m[1][1])+(t*m[2][1])+(m[3][1]);
    matrixA[2]=(t*t*t*m[0][2])+(t*t*m[1][2])+(t*m[2][2])+(m[3][2]);
    matrixA[3]=(t*t*t*m[0][3])+(t*t*m[1][3])+(t*m[2][3])+(m[3][3]);
     
    int ind1 = indices[0];
    int ind2 = indices[1];
    int ind3 = indices[2];
    int ind4 = indices[3];

    Coordinates* p1= vertix[ind1];
    Coordinates* p2= vertix[ind2];
    Coordinates* p3= vertix[ind3];
    Coordinates* p4= vertix[ind4];
    
    //pos=(T*M)*P
    pos[0] = (matrixA[0]*p1->getX()) + (matrixA[1]*p2->getX()) + (matrixA[2]*p3->getX()) + (matrixA[3]*p4->getX());
    pos[1] = (matrixA[0]*p1->getY()) + (matrixA[1]*p2->getY()) + (matrixA[2]*p3->getY()) + (matrixA[3]*p4->getY());
    pos[2] = (matrixA[0]*p1->getZ()) + (matrixA[1]*p2->getZ()) + (matrixA[2]*p3->getZ()) + (matrixA[3]*p4->getZ());
     
}



void Translation::getGlobalCatmullRomPoint(float gt, float *pos, std::vector<Coordinates*> vertixs) {

    int tamanho = points.size();
	float t = gt * tamanho; 
	int index = floor(t);  
	t = t - index; 
	
	int indices[4]; 
	indices[0] = (index + tamanho-1)%tamanho;	
	indices[1] = (indices[0]+1)%tamanho;
	indices[2] = (indices[1]+1)%tamanho; 
	indices[3] = (indices[2]+1)%tamanho;

	getCatmullRomPoint(t, indices ,pos , vertixs);
}



std::vector<Coordinates*> Translation::catmullCurve(){
    float pos[3];
    float i;
    std::vector<Coordinates*> catmullPoints;
    for(i=0; i<1; i+=0.01){
        getGlobalCatmullRomPoint(i,pos,points);
        Coordinates * coord = new Coordinates(pos[0],pos[1],pos[2]);
        catmullPoints.push_back(coord);
    }
    return catmullPoints;
}

