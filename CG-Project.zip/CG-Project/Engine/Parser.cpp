#include "Group.h"
#include "Color.h"
#include "Translation.h"
#include "Rotation.h"
#include "Scale.h"

#include "tinyxml/tinyxml2.h"

using namespace tinyxml2;

Color* parseColor(tinyxml2::XMLElement* x){
    float r = 0, g = 0, b = 0;
     
    x->QueryFloatAttribute("Red", &r);
    x->QueryFloatAttribute("Green", &g);
    x->QueryFloatAttribute("Blue", &b);

    Color* color = new Color(r,g,b);
    return color;   
}

Translation* parseTranslation(tinyxml2::XMLElement* e){
    float time = 0, x=0 ,y=0 ,z=0;
    std::vector<Coordinates*> points;

    e->QueryFloatAttribute("time",&time);
    
    if(time){
        for(tinyxml2::XMLElement* point = e->FirstChildElement();point;point=point->NextSiblingElement()){
            point->QueryFloatAttribute("X",&x);
            point->QueryFloatAttribute("Y",&y);
            point->QueryFloatAttribute("Z",&z);
            
            Coordinates* coord = new Coordinates(x,y,z);

            points.push_back(coord);
        }
        
        Translation* t = new Translation(time,points,0,0,0);
        return t;
    }

    else{
        e->QueryFloatAttribute("X",&x);
        e->QueryFloatAttribute("Y",&y);
        e->QueryFloatAttribute("Z",&z);

        Translation* t = new Translation(0,points,x,y,z);
        return t;
    }
}



Scale* parseScale(tinyxml2::XMLElement* e){
    float x = 0, y = 0, z = 0;
    
    e->QueryFloatAttribute("X", &x);
    e->QueryFloatAttribute("Y", &y);
    e->QueryFloatAttribute("Z", &z);

    Scale* s = new Scale(x,y,z);
    return s;
}


Rotation* parseRotation(tinyxml2::XMLElement* e){
    float time = 0, angle = 0, x = 0, y = 0, z = 0;

    e -> QueryFloatAttribute("time", &time);
    e -> QueryFloatAttribute("Angle", &angle);
    e -> QueryFloatAttribute("X", &x);
    e -> QueryFloatAttribute("Y", &y);
    e -> QueryFloatAttribute("Z", &z);

    Rotation* r = new Rotation(angle,time, x, y, z);
    return r;
}