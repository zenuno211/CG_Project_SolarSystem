#ifndef ROTATION_H
#define ROTATION_H

class Rotation{
    float time;
    float angle;
    float x;
    float y;
    float z;    

public: 
    Rotation();
    Rotation(float angleR,float t, float x, float y, float z);
    float getAngle();
    float getX();
    float getY();
    float getZ();
    float getTime();
};

#endif
