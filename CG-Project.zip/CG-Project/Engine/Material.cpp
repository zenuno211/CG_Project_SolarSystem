#include "Material.h"

Material::Material(){
    diffuse = NULL;
    specular = NULL;
    emissive = NULL;
    ambient = NULL;
}

