#include <stdio.h>
#include <stdlib.h>
#include <IL/il.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glew.h>
#include <GL/glut.h>
#endif

#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>
//#include "tinyxml/tinyxml2.h"
#include <string>
#include <iostream>
#include <fstream>

#include "main.h"
#include "./Parser.cpp"

using namespace std;
using namespace tinyxml2;

float px = 0;
float py = 0;
float pz = 0;

float dx = 0;
float dy = 0;
float dz = 0;

float alpha = M_PI/4;
float beta = M_PI/4;
float radium = 50;

float SpeedZoom = 1;

int frame = 0;
int tempo = 0;

GLenum OPTION = GL_FILL;

std::vector<Group*> groups;

float isPoint=0;
float lightX;
float lightY;
float lightZ;

int loadTexture(string s) {
    unsigned int t, tw, th;
    unsigned char *texData;
    unsigned int texID;

    // Iniciar o DevIL
    ilInit();

    // Colocar a origem da luz no canto inferior esquerdo
    ilEnable(IL_ORIGIN_SET);
    ilOriginFunc(IL_ORIGIN_LOWER_LEFT);

    // Carregar a textura para memória
    ilGenImages(1,&t);
    ilBindImage(t);
    ilLoadImage((ILstring)s.c_str());
    tw = ilGetInteger(IL_IMAGE_WIDTH);
    th = ilGetInteger(IL_IMAGE_HEIGHT);

    ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);
    texData = ilGetData();

    //Gerar a textura para a placa gráfica
    glGenTextures(1,&texID);

    glBindTexture(GL_TEXTURE_2D,texID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

    //Upload dos dados da imagem
    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, tw, th, GL_RGBA, GL_UNSIGNED_BYTE, texData);

    glGenerateMipmap(GL_TEXTURE_2D);
    //glBindTexture(GL_TEXTURE_2D, 0);

    return texID;
}




std::vector<Group*> getGroup(tinyxml2::XMLElement* group){

        std::vector<Group*> gruppos;
        std::string ficheiroToLoad; //nome das figura presentes no ficheiro XML
        string generated_path = "../Ficheiros3D/";
        string generated_path_Text = "../Textures/";

        Group* grupo = new Group();
        Color* color = new Color();

        if(group){
            
            if (strcmp(group->FirstChildElement()->Value(),"group") == 0){
                group = group->FirstChildElement();
            }

            tinyxml2::XMLElement* here; // apontador para percorrer os childs

            for(here=group->FirstChildElement(); (strcmp(here->Value(),"models") != 0); here = here->NextSiblingElement()){   //Até encontrar models

                Scale* scale = new Scale();
                Translation* translation = new Translation();
                Rotation* rotation = new Rotation();

                Transformations* transf = new Transformations(translation,rotation,scale,color); //inicializar uma transformação para cada uma que leia de forma a dar ordem

                if((strcmp(here->Value(),"color") == 0)){
                    color = parseColor(here);
                    transf->setColor(color);
                }

                else if((strcmp(here->Value(),"translate") == 0)){
                    translation = parseTranslation(here);
                    transf->setTranslation(translation);
                }

                else if((strcmp(here->Value(),"rotate") == 0)){
                    rotation = parseRotation(here);
                    transf->setRotation(rotation);                      
                }

                else if((strcmp(here->Value(),"scale") == 0)){
                    scale = parseScale(here);
                    transf->setScale(scale);                    
                }
                
                grupo->InsereTransformations(transf);

            }


            tinyxml2::XMLElement* models;
            models = group->FirstChildElement("models");
            tinyxml2::XMLElement* model = models->FirstChildElement("model");
            Figura* novafig = new Figura();

            while(model != nullptr){
                string novafigura = generated_path + model->Attribute("file");
                ficheiroToLoad = novafigura;

                Material* material = new Material();
                novafig->setMaterial(material);

                if(model->Attribute("texture")){
                    string novaTextura = generated_path_Text + model->Attribute("texture");
                    int t = loadTexture(novaTextura);
                    novafig->setTexture(t);
                    int newr = novafig->getTextureID();
                }
                
                if (model->Attribute("diffR")){
                    material->diffuse = (float*)malloc(sizeof(float)*4);
                    material->diffuse[0] = model->DoubleAttribute("diffR");
                    material->diffuse[1] = model->DoubleAttribute("diffG");
                    material->diffuse[2] = model->DoubleAttribute("diffB");
                    material->diffuse[3] = 1.0f;
                    novafig->setMaterial(material);
                }

                if (model->Attribute("specR")){
                    material->specular = (float*)malloc(sizeof(float)*4);
                    material->specular[0] = model->DoubleAttribute("specR");
                    material->specular[1] = model->DoubleAttribute("specG");
                    material->specular[2] = model->DoubleAttribute("specB");
                    material->specular[3] = 1.0f;
                    novafig->setMaterial(material);
                }

                if (model->Attribute("emiR")){
                    material->emissive = (float*)malloc(sizeof(float)*4);
                    material->emissive[0] = model->DoubleAttribute("emiR");
                    material->emissive[1] = model->DoubleAttribute("emiG");
                    material->emissive[2] = model->DoubleAttribute("emiB");
                    material->emissive[3] = 1.0f;
                    novafig->setMaterial(material);
                }

                if (model->Attribute("ambR")){
                    material->ambient = (float*)malloc(sizeof(float)*4);
                    material->ambient[0] = model->DoubleAttribute("ambR");
                    material->ambient[1] = model->DoubleAttribute("ambG");
                    material->ambient[2] = model->DoubleAttribute("ambB");
                    material->ambient[3] = 1.0f;
                    novafig->setMaterial(material);
                }
                
                model = model->NextSiblingElement("model");
            }

            ifstream file;
            file.open(ficheiroToLoad);
            int nrVertices, contador;
            file >> nrVertices;

            //Coordenadas da figura
            contador=0;
            while (contador < nrVertices) {
                Coordinates* coord = new Coordinates();
                file >> coord->coordX >> coord->coordY >> coord->coordZ;
                novafig->InsereCoordenada(coord);
                contador++;
            }
            
            //Normais
            contador=0;
            while (contador < nrVertices) {
                Coordinates* norm = new Coordinates();
                file >> norm->coordX >> norm->coordY >> norm->coordZ;
                novafig->InsereNormal(norm);
                contador++;
            }

            //Pts de textura
            contador=0;
            while(contador < nrVertices && !file.eof()){
                Textures* tex = new Textures();
                file >> tex->coordX >> tex->coordY;
                novafig->InsereTextura(tex);
                contador++;
            }

            grupo->setFigure(novafig);

                     
            std::vector<Group*> littleGroup;
            if(group->FirstChildElement("group")){
                littleGroup = getGroup( group->FirstChildElement("group"));
                grupo->setNext(littleGroup);
            }

            gruppos.push_back(grupo);

            std::vector<Group*> brotherGroup;
            if(group->NextSiblingElement("group")){
                brotherGroup = getGroup(group->NextSiblingElement("group"));
                for(int i=0; i<brotherGroup.size(); i++){
                    gruppos.push_back(brotherGroup[i]);
                }
                gruppos.size();
            }

            return gruppos;

        }

}



std::vector<Group*> getFigura() {

    std::vector<Group*> groups;
    //load do ficheiro xml
    tinyxml2::XMLDocument doc;
    tinyxml2::XMLError erro = doc.LoadFile("../Engine/XML_Files/SistemaLuzesTexturas.xml"); //carregar/abre o ficheiro XML
    if (erro != XML_SUCCESS) {
        printf("ERRO AO LER FICHEIRO XML !\n");
    }

    //le do ficheiro xml as figuras que temos de desenhar e poe no vetor acima criado
    tinyxml2::XMLElement* scene = doc.FirstChildElement("scene"); //childs
    if (scene) {
        
        if(scene->FirstChildElement("lights")){
            tinyxml2::XMLElement* light = scene->FirstChildElement("lights")->FirstChildElement("light");
            std::string lightType = light->Attribute("type");
            if(strcmp(light->Attribute("type"),"POINT") == 0){
                isPoint = 1;
                lightX = atof(light->Attribute("posX"));
                lightY = atof(light->Attribute("posY"));
                lightZ = atof(light->Attribute("posZ"));
            }
            else if(strcmp(light->Attribute("type"),"DIRECTIONAL") == 0){
                 lightX = atof(light->Attribute("posX"));
                 lightY = atof(light->Attribute("posY"));
                 lightZ = atof(light->Attribute("posZ"));
            }
        }
        
        tinyxml2::XMLElement* group = scene->FirstChildElement("group");
        groups = getGroup(group);
    }


    return groups;
    
}


void desenhaFiguraVBO(Figura* figura) {
    
    GLuint buffers[3];
    glGenBuffers(3, buffers);
    
    std::vector<Coordinates*> cd = figura->getFigura();
    std::vector<Coordinates*>::iterator it; //apontador para apontador de coordenada
    int vertices = figura->countVertix();
    int nrvertices = 0;

    float *arrayVrt = new float[vertices];
    for(it = cd.begin(); it != cd.end(); it++) { 
        arrayVrt[nrvertices++] = (*it)->getX();
        arrayVrt[nrvertices++] = (*it)->getY();
        arrayVrt[nrvertices++] = (*it)->getZ(); 
    }

    std::vector<Coordinates*> norm = figura->getNormals();
    std::vector<Coordinates*>::iterator itNormals; //apontador para apontador de normals
    int normals = figura->countNormals();
    int nrNormals = 0;

    float *arrayNormals = new float[normals];
    for(itNormals = norm.begin(); itNormals != norm.end(); itNormals++){
        arrayNormals[nrNormals++] = (*itNormals)->getX();
        arrayNormals[nrNormals++] = (*itNormals)->getY();
        arrayNormals[nrNormals++] = (*itNormals)->getZ();
    }


    std::vector<Textures*> text = figura->getTextures();
    std::vector<Textures*>::iterator itTextures; //apontador para apontador de textura
    int textures = figura->countTextures();
    int nrTextures = 0;

    float *arrayTextures = new float[textures];
    for(itTextures = text.begin(); itTextures != text.end(); itTextures++) { 
        arrayTextures[nrTextures++] = (*itTextures)->getX();
        arrayTextures[nrTextures++] = (*itTextures)->getY();
    }
    
    glBindBuffer(GL_ARRAY_BUFFER, buffers[0]);
    glBufferData(GL_ARRAY_BUFFER, nrvertices*sizeof(float), arrayVrt, GL_STATIC_DRAW);
    glVertexPointer(3,GL_FLOAT,0,0);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[1]);
    glBufferData(GL_ARRAY_BUFFER, nrNormals*sizeof(float), arrayNormals, GL_STATIC_DRAW);
    glNormalPointer(GL_FLOAT,0,0);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[2]);
    glBufferData(GL_ARRAY_BUFFER, nrTextures*sizeof(float), arrayTextures, GL_STATIC_DRAW);
    glTexCoordPointer(2,GL_FLOAT,0,0);

    glDrawArrays(GL_TRIANGLES, 0, vertices/3); //GL_TRIANGLES  //GL_TRIANGLE_STRIP

    delete[] arrayVrt;
    delete[] arrayNormals;
    delete[] arrayTextures;

    glDeleteBuffers(3, buffers);
}



void desenhaOrbita(std::vector<Coordinates*> curvePoints){

    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < curvePoints.size(); ++i) {
        glVertex3f(curvePoints[i]->getX(), curvePoints[i]->getY(), curvePoints[i]->getZ());
    }
    glEnd();
}



void drawXML(std::vector<Group*> groups){
    int i=0,j=0;
    float pos[3];

    while(i<groups.size()){
        std::vector<Transformations*> transformations = groups[i]->getTransformations();
        std::vector<Group*> proximos = groups[i]->getNext();

        glPushMatrix();
        while(j<transformations.size()){

            Color* color = transformations[j]->getColor(); 
            Rotation* rotation = transformations[j]->getRotation();
            Translation* translation = transformations[j]->getTranslation();
            Scale* scale = transformations[j]->getScale();
            
            if(rotation->getTime()!=0){ //Se for imposto tempo
                float time = glutGet(GLUT_ELAPSED_TIME) % (int)(rotation->getTime()*1000);
                float angleToRotate = (time*360)/(rotation->getTime()*1000);
                glRotatef(angleToRotate,rotation->getX(),rotation->getY(),rotation->getZ());
            }
            else{ //Caso não seja imposto tempo
                glRotatef(rotation->getAngle(),rotation->getX(),rotation->getY(),rotation->getZ());
            }

            if(translation->getTime()!=0 && translation->getPoints().size()>=4 ){   // >= 4 devido a regras de Ctamull-Rom
                float times = glutGet(GLUT_ELAPSED_TIME) % (int)(translation->getTime()*1000);
                float timeToTranslate = times/(translation->getTime()*1000);
                std::vector<Coordinates*> points = translation->getPoints();//buscar pontos
                std::vector<Coordinates*> pontosCurva = translation->catmullCurve();//buscar curva
                int p = pontosCurva.size();
                desenhaOrbita(pontosCurva);//desenhar orbita
                translation->getGlobalCatmullRomPoint(timeToTranslate,pos,points);//buscar pontos de catmull-rom
                glTranslatef(pos[0],pos[1],pos[2]);//fazer translate
            }
            else{
                glTranslatef(translation->getX(),translation->getY(),translation->getZ());
            }

            glScalef(scale->getX(),scale->getY(),scale->getZ());
            glColor3f(color->getRed(),color->getGreen(),color->getBlue());
            j++;
        }

        glMaterialf(GL_FRONT, GL_SHININESS, 128); // Para a luz especular 
        if (groups[i]->getFigure()->getMaterial()->ambient)
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, groups[i]->getFigure()->getMaterial()->ambient);
        if (groups[i]->getFigure()->getMaterial()->diffuse)
            glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, groups[i]->getFigure()->getMaterial()->diffuse);
        if (groups[i]->getFigure()->getMaterial()->emissive)
            glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, groups[i]->getFigure()->getMaterial()->emissive);
        if (groups[i]->getFigure()->getMaterial()->specular){
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, groups[i]->getFigure()->getMaterial()->specular);
        }

        //glBegin(GL_TRIANGLES); //(Penso que não seja preciso porque agora são VBOs)
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D,groups[i]->getFigure()->getTextureID());
        desenhaFiguraVBO(groups[i]->getFigure());
        glBindTexture(GL_TEXTURE_2D,0);
        glDisable(GL_TEXTURE_2D);
        //glEnd(); //(Penso que não seja preciso porque agora são VBOs)
        drawXML(proximos);//para desenhar os grupos que estão dentro dos grupos!!!!
        glPopMatrix();

         //reiniciar para valores default do glMaterial para nao aplicar aos futuros objetos
        float emission[4] = {0,0,0,1};
        float ambient[4] = {0.2,0.2,0.2,1.0};
        float specular[4] = {0,0,0,1};
        float diffuse[4] = {0,0,0,1.0};
        glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, emission);
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse);

        i++;
        j=0;
    }
}




void changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window with zero width).
	if(h == 0)
		h = 1;

	// compute window's aspect ratio 
	float ratio = w * 1.0 / h;

	// Set the projection matrix as current
	glMatrixMode(GL_PROJECTION);
	// Load Identity Matrix
	glLoadIdentity();
	
	// Set the viewport to be the entire window
    glViewport(0, 0, w, h);

	// Set perspective
	gluPerspective(45.0f ,ratio, 1.0f ,1000.0f);

	// return to the model view matrix mode
	glMatrixMode(GL_MODELVIEW);
}


void fps(){
    float fps;
    int time;
    char title[56];

    frame++;
    time = glutGet(GLUT_ELAPSED_TIME);

    if(time - tempo > 1000){
        fps = frame*1000 / (time-tempo);
        tempo = time;
        frame = 0;
        sprintf(title, "CG-Project | %.f FPS",fps);
        glutSetWindowTitle(title);
    }

}

//SPOTLIGHT
//glLightf(m_glLightNumber, GL_SPOT_CUTOFF, m_cutOffAngle);
//glLightfv(m_glLightNumber, GL_SPOT_DIRECTION, (const float *)&direction);
//glLightf(m_glLightNumber, GL_SPOT_EXPONENT, m_spotExponent);


void renderScene(void) {

    float pos[4] = {lightX,lightY,lightZ,isPoint};
	
    // clear buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// set the camera
	glLoadIdentity();

    px = radium*cosf(beta)*sinf(alpha);
    py = radium*sinf(beta);
    pz = radium*cosf(alpha)*cosf(beta);
    gluLookAt(px+dx, py+dy, pz+dz,
              dx, dy, dz,
              0.0f, 1.0f, 0.0f);

    glLightfv(GL_LIGHT0,GL_POSITION, pos);
    GLfloat dark[4] = {0.2, 0.2, 0.2, 1.0};
    GLfloat white[4] = {1.0, 1.0, 1.0, 1.0};
    // light colors
    glLightfv(GL_LIGHT0, GL_AMBIENT, white); //luz forte
    glLightfv(GL_LIGHT0, GL_DIFFUSE, white); //luz forte
    glLightfv(GL_LIGHT0, GL_SPECULAR, white); //luz forte
    // put the geometric transformations here
    
    // put drawing instructions here
    /* glBegin(GL_LINES);
    // X axis in red
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(-100.0f, 0.0f, 0.0f);
    glVertex3f( 100.0f, 0.0f, 0.0f);
    // Y Axis in Green
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(0.0f,-100.0f, 0.0f);
    glVertex3f(0.0f, 100.0f, 0.0f);
    // Z Axis in Blue
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(0.0f, 0.0f,-100.0f);
    glVertex3f(0.0f, 0.0f, 100.0f);
    glEnd(); */
   
    glPolygonMode(GL_FRONT_AND_BACK,OPTION);

    drawXML(groups);


    fps();
	// End of frame
	glutSwapBuffers();
}




// write function to process keyboard events
void reactKeyboard(unsigned char key, int x, int y) {
    switch(key){
        case 'd':
            dx+=1;
            break;
        case 'a':
            dx-=1;
            break;
        case 'w':
            dy+=1;
            break;
        case 's':
            dy-=1;
            break;
        case 'q':
            dz+=1;
            break;
        case 'z':
            dz-=1;
            break;
        case 'l':
            OPTION = GL_LINE;
            break;
        case 'p':
            OPTION = GL_POINT;
            break;
        case 'f':
            OPTION = GL_FILL;
            break;    
        case '+':
            SpeedZoom+=0.5;
            break;
        case '-':
            SpeedZoom-=0.5;
            break;

    }
    glutPostRedisplay();
}


void reactToSpecial(int key_code, int x, int y) {
    switch(key_code){
        case GLUT_KEY_RIGHT:
            alpha = alpha + 0.05;
            break;
        case GLUT_KEY_LEFT:
            alpha = alpha - 0.05;
            break;
        case GLUT_KEY_UP:
            if (beta + 0.05 >= 1.5)
                beta = 1.5;
            else
                beta = beta + 0.05;
            break;
        case GLUT_KEY_DOWN:
            if (beta - 0.05 <= -1.5)
                beta = -1.5;
            else
                beta = beta - 0.05;
            break;
        case GLUT_KEY_PAGE_DOWN:
            radium -= SpeedZoom;
            break;
        case GLUT_KEY_PAGE_UP:
            radium += SpeedZoom;
            break;

    }
    glutPostRedisplay();
}

void reactMouse(int button, int state, int x, int y) {
    if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
        alpha = alpha + 0.05;
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        if (beta - 0.05 <= -1.5)
            beta = -1.5;
        else
            beta = beta - 0.05;
    }
    glutPostRedisplay();
}

void reactMouseMove(int x, int y) {
    alpha = alpha + 0.01;
    glutPostRedisplay();
}

int main(int argc, char** argv) {
     
    //init GLUT and the window
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(0, 50);
    glutInitWindowSize(800, 800);
    glutCreateWindow("CG@DI-UM-20/21");
    glewInit();

    groups = getFigura();


    // Required callback registry
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutReshapeFunc(changeSize);

    //  OpenGL settings
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE); //Para esconder as faces de trás
    glEnable(GL_POLYGON_OFFSET_FILL);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glEnable(GL_NORMALIZE);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glutKeyboardFunc(reactKeyboard); //Mexe com a interação com teclas
    glutSpecialFunc(reactToSpecial); //Mexe com a interação com teclas especiais
    glutMouseFunc(reactMouse); //Mexe de acordo com o click do rato
    //glutPassiveMotionFunc(reactMouseMove); //mexe com o movimento do rato

 
    // enter GLUT's main cycle
    glutMainLoop();

    return 1;

}

